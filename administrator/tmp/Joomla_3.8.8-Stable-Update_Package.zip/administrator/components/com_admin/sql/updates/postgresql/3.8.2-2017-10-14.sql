--
-- Add index for alias check #__content
--

CREATE INDEX "#__content_idx_alias" ON "#__content" ("alias");
